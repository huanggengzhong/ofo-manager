import React from 'react'
export default class Topic extends React.Component {

    render() {
        return (
            <div>
                this is topic page.
            </div>
        );
    }
}