import React from 'react'
export default class Home extends React.Component {

    render() {
        return (
            <div>
                404 No Pages.
            </div>
        );
    }
}